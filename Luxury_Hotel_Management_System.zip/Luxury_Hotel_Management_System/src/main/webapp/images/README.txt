This folder contains images for the Luxury Hotel Management System.

The following images should be added to this folder:
- hotel-hero.jpg: A high-quality image of the hotel for the homepage hero section
- room-standard.jpg: Image of a standard room
- room-deluxe.jpg: Image of a deluxe room
- room-suite.jpg: Image of a suite
- room-presidential.jpg: Image of a presidential suite
- hotel-logo.png: Hotel logo (if available)
- amenities images (pool, spa, restaurant, etc.)

Note: For development purposes, we're using placeholder images from Unsplash in the HTML/JSP files.
In a production environment, these should be replaced with actual hotel images stored in this folder.
