-- Create database
CREATE DATABASE IF NOT EXISTS luxury_hotel_db;
USE luxury_hotel_db;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    role ENUM('ADMIN', 'GUEST') NOT NULL DEFAULT 'GUEST',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create rooms table
CREATE TABLE IF NOT EXISTS rooms (
    room_id INT AUTO_INCREMENT PRIMARY KEY,
    room_number VARCHAR(10) NOT NULL UNIQUE,
    room_type ENUM('STANDARD', 'DELUXE', 'SUITE', 'PRESIDENTIAL') NOT NULL,
    price_per_night DECIMAL(10, 2) NOT NULL,
    capacity INT NOT NULL,
    description TEXT,
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    room_id INT NOT NULL,
    check_in_date DATE NOT NULL,
    check_out_date DATE NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    booking_status ENUM('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- Create staff table
CREATE TABLE IF NOT EXISTS staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    staff_role ENUM('MANAGER', 'RECEPTIONIST', 'HOUSEKEEPER', 'MAINTENANCE', 'CHEF', 'WAITER', 'SECURITY') NOT NULL,
    hire_date DATE,
    salary DECIMAL(10, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create billing table
CREATE TABLE IF NOT EXISTS billing (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status ENUM('PENDING', 'PAID', 'REFUNDED', 'CANCELLED') DEFAULT 'PENDING',
    payment_date DATETIME,
    payment_method ENUM('CREDIT_CARD', 'DEBIT_CARD', 'CASH', 'BANK_TRANSFER', 'PAYPAL') DEFAULT NULL,
    transaction_id VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- Create feedback table
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    booking_id INT,
    comment TEXT,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    date_submitted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_published BOOLEAN DEFAULT FALSE,
    staff_response TEXT,
    response_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL
);

-- Insert admin user (password: admin123) if not exists
INSERT INTO users (username, password, email, first_name, last_name, role)
SELECT 'admin', 'admin123', 'admin@luxuryhotel.com', 'Admin', 'User', 'ADMIN'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE username = 'admin'
);

-- Insert sample rooms if not exists
INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '101', 'STANDARD', 100.00, 2, 'Standard room with basic amenities'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '101'
);

INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '102', 'STANDARD', 100.00, 2, 'Standard room with basic amenities'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '102'
);

INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '201', 'DELUXE', 200.00, 2, 'Deluxe room with premium amenities'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '201'
);

INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '202', 'DELUXE', 200.00, 2, 'Deluxe room with premium amenities'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '202'
);

INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '301', 'SUITE', 350.00, 4, 'Luxury suite with separate living area'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '301'
);

INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description)
SELECT '401', 'PRESIDENTIAL', 500.00, 6, 'Presidential suite with premium amenities and services'
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM rooms WHERE room_number = '401'
);

-- Insert sample staff data
INSERT INTO staff (full_name, email, phone, staff_role, hire_date, salary, is_active)
SELECT 'John Smith', 'john.smith@luxuryhotel.com', '555-123-4567', 'MANAGER', '2020-01-15', 75000.00, TRUE
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM staff WHERE email = 'john.smith@luxuryhotel.com'
);

INSERT INTO staff (full_name, email, phone, staff_role, hire_date, salary, is_active)
SELECT 'Emily Johnson', 'emily.johnson@luxuryhotel.com', '555-234-5678', 'RECEPTIONIST', '2021-03-10', 45000.00, TRUE
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM staff WHERE email = 'emily.johnson@luxuryhotel.com'
);

INSERT INTO staff (full_name, email, phone, staff_role, hire_date, salary, is_active)
SELECT 'Michael Brown', 'michael.brown@luxuryhotel.com', '555-345-6789', 'HOUSEKEEPER', '2021-05-20', 35000.00, TRUE
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM staff WHERE email = 'michael.brown@luxuryhotel.com'
);

INSERT INTO staff (full_name, email, phone, staff_role, hire_date, salary, is_active)
SELECT 'Sarah Davis', 'sarah.davis@luxuryhotel.com', '555-456-7890', 'CHEF', '2020-11-05', 60000.00, TRUE
FROM dual
WHERE NOT EXISTS (
    SELECT 1 FROM staff WHERE email = 'sarah.davis@luxuryhotel.com'
);
