-- Additional tables for Luxury Hotel Management System

-- Create staff table
CREATE TABLE IF NOT EXISTS staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    staff_role ENUM('MANAGER', 'RECEPTIONIST', 'HOUSEKEEPER', 'MAINTENANCE', 'CHEF', 'WAITER', 'SECURITY') NOT NULL,
    hire_date DATE,
    salary DECIMAL(10, 2),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create billing table
CREATE TABLE IF NOT EXISTS billing (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status ENUM('PENDING', 'PAID', 'REFUNDED', 'CANCELLED') DEFAULT 'PENDING',
    payment_date DATETIME,
    payment_method ENUM('CREDIT_CARD', 'DEBIT_CARD', 'CASH', 'BANK_TRANSFER', 'PAYPAL') DEFAULT NULL,
    transaction_id VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

-- Create feedback table
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    booking_id INT,
    comment TEXT,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    date_submitted TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_published BOOLEAN DEFAULT FALSE,
    staff_response TEXT,
    response_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE SET NULL
);


-- Insert sample billing data (will only work if there are bookings in the system)
-- Note: You may need to adjust the booking_id values to match existing bookings
INSERT INTO billing (booking_id, total_amount, payment_status, payment_date, payment_method, transaction_id)
SELECT 
    b.booking_id, 
    b.total_price, 
    'PAID', 
    DATE_ADD(b.created_at, INTERVAL 1 DAY), 
    'CREDIT_CARD', 
    CONCAT('TXN-', FLOOR(RAND() * 1000000))
FROM 
    bookings b
WHERE 
    b.booking_status = 'CONFIRMED'
LIMIT 5;

-- Insert sample feedback data (will only work if there are users and bookings in the system)
-- Note: You may need to adjust the user_id and booking_id values to match existing data
INSERT INTO feedback (user_id, booking_id, comment, rating, is_published, staff_response, response_date)
SELECT 
    b.user_id,
    b.booking_id,
    'The room was very clean and comfortable. Staff was friendly and helpful.',
    5,
    TRUE,
    'Thank you for your kind feedback! We\'re glad you enjoyed your stay.',
    DATE_ADD(b.check_out_date, INTERVAL 3 DAY)
FROM 
    bookings b
WHERE 
    b.booking_status = 'COMPLETED'
LIMIT 3;

INSERT INTO feedback (user_id, booking_id, comment, rating, is_published)
SELECT 
    b.user_id,
    b.booking_id,
    'Good experience overall, but the breakfast could be improved.',
    4,
    TRUE
FROM 
    bookings b
WHERE 
    b.booking_status = 'COMPLETED' AND
    b.booking_id NOT IN (SELECT booking_id FROM feedback WHERE booking_id IS NOT NULL)
LIMIT 2;
