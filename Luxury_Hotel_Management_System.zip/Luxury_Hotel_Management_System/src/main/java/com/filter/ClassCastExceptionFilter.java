package com.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Filter specifically for handling class cast exceptions between different User implementations
 */
@WebFilter(filterName = "ClassCastExceptionFilter", urlPatterns = {"/*"})
public class ClassCastExceptionFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        try {
            // Check if there's a session
            HttpSession session = httpRequest.getSession(false);
            if (session != null) {
                // Get the current user from session
                Object userObj = session.getAttribute("currentUser");
                if (userObj != null) {
                    // Check if the user object is from the conflicting package
                    String className = userObj.getClass().getName();
                    if (className.contains("com.example.luxury_hotel_management_system")) {
                        // Remove the conflicting user object
                        session.removeAttribute("currentUser");
                        // Redirect to login page
                        httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
                        return;
                    }
                }
            }
            
            // Continue with the request
            chain.doFilter(request, response);
        } catch (Exception e) {
            // Log the error
            System.err.println("Error in ClassCastExceptionFilter: " + e.getMessage());
            e.printStackTrace();
            
            // Forward to error page
            httpRequest.setAttribute("errorMessage", "Class loading error: " + e.getMessage());
            httpRequest.getRequestDispatcher("/WEB-INF/views/error/class-error.jsp").forward(httpRequest, httpResponse);
        }
    }
    
    @Override
    public void destroy() {
        // Cleanup code
    }
}
