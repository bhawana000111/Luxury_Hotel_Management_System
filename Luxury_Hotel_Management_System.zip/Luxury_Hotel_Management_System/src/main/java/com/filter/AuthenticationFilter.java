package com.filter;

import com.util.SessionUtil;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Filter for authentication and authorization
 */
@WebFilter(filterName = "AuthenticationFilter", urlPatterns = {"/admin/*", "/guest/*"})
public class AuthenticationFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        try {
            // Check if user is logged in
            if (!SessionUtil.isLoggedIn(httpRequest)) {
                httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
                return;
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error checking if user is logged in: " + e.getMessage());
            e.printStackTrace();

            // Redirect to login page
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }

        try {
            // Check if user has appropriate role for admin pages
            String requestURI = httpRequest.getRequestURI();
            if (requestURI.contains("/admin/")) {
                try {
                    if (!SessionUtil.isAdmin(httpRequest)) {
                        httpResponse.sendRedirect(httpRequest.getContextPath() + "/guest/dashboard");
                        return;
                    }
                } catch (Exception e) {
                    // Log the error
                    System.err.println("Error checking if user is admin: " + e.getMessage());
                    e.printStackTrace();

                    // Redirect to login page
                    httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
                    return;
                }
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error checking request URI: " + e.getMessage());
            e.printStackTrace();

            // Redirect to login page
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login");
            return;
        }

        // Continue with the request
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Cleanup code if needed
    }
}
