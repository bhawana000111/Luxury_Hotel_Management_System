package com.filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Filter for handling errors
 */
@WebFilter(urlPatterns = "/*")
public class ErrorHandlingFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        try {
            // Continue with the request
            chain.doFilter(request, response);
        } catch (ClassCastException e) {
            // Log the error
            System.err.println("Caught ClassCastException in ErrorHandlingFilter: " + e.getMessage());
            e.printStackTrace();

            // Set error message
            httpRequest.setAttribute("errorMessage", "Class loading error: " + e.getMessage());

            // Forward to class error page
            httpRequest.getRequestDispatcher("/WEB-INF/views/error/class-error.jsp").forward(httpRequest, httpResponse);
        } catch (Exception e) {
            // Log the error
            System.err.println("Caught exception in ErrorHandlingFilter: " + e.getMessage());
            e.printStackTrace();

            // Set error message
            httpRequest.setAttribute("errorMessage", "An unexpected error occurred: " + e.getMessage());

            // Forward to error page
            httpRequest.getRequestDispatcher("/WEB-INF/views/error/500.jsp").forward(httpRequest, httpResponse);
        }
    }

    @Override
    public void destroy() {
        // Cleanup code
    }
}
