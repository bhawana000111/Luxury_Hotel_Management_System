package com.filter;

import com.util.SessionUtil;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Filter for session management
 */
@WebFilter(filterName = "SessionFilter", urlPatterns = {"/*"})
public class SessionFilter implements Filter {

    // Paths that don't require session checks
    private static final String[] EXCLUDED_PATHS = {
        "/css/", "/js/", "/images/", "/fonts/",
        "/login", "/register", "/", "/about", "/contact",
        "/rooms", "/events", "/blog", "/favicon.ico",
        "/diagnostic.jsp", "/test-db", "/init-db", "/error/"
    };

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();

        // Check if the request is for an excluded path
        if (isExcludedPath(requestURI, contextPath)) {
            chain.doFilter(request, response);
            return;
        }

        try {
            // Check if user is logged in
            if (!SessionUtil.isLoggedIn(httpRequest)) {
                httpResponse.sendRedirect(contextPath + "/login");
                return;
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error checking if user is logged in: " + e.getMessage());
            e.printStackTrace();

            // Redirect to login page
            httpResponse.sendRedirect(contextPath + "/login");
            return;
        }

        try {
            // Check if session has timed out
            if (SessionUtil.isSessionTimedOut(httpRequest)) {
                // Invalidate the session
                SessionUtil.invalidateSession(httpRequest);
                // Set timeout message
                httpRequest.getSession().setAttribute("message", "Your session has timed out. Please login again.");
                httpResponse.sendRedirect(contextPath + "/login");
                return;
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error checking if session has timed out: " + e.getMessage());
            e.printStackTrace();

            // Redirect to login page
            httpResponse.sendRedirect(contextPath + "/login");
            return;
        }

        try {
            // Refresh the session
            SessionUtil.refreshSession(httpRequest);
        } catch (Exception e) {
            // Log the error but continue
            System.err.println("Error refreshing session: " + e.getMessage());
            e.printStackTrace();
        }

        // Continue with the request
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Cleanup code if needed
    }

    /**
     * Check if the request URI is for an excluded path
     * @param requestURI Request URI
     * @param contextPath Context path
     * @return true if the path is excluded, false otherwise
     */
    private boolean isExcludedPath(String requestURI, String contextPath) {
        String path = requestURI.substring(contextPath.length());

        for (String excludedPath : EXCLUDED_PATHS) {
            if (path.startsWith(excludedPath)) {
                return true;
            }
        }

        return false;
    }
}
