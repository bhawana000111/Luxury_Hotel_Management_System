package com.service;

import com.dao.UserDAO;
import com.model.User;
import com.util.PasswordUtil;
import com.util.UserAdapter;
import com.util.ValidationUtil;

/**
 * Service class for user-related operations
 */
public class UserService {
    private final UserDAO userDAO;

    public UserService() {
        this.userDAO = new UserDAO();
    }

    /**
     * Register a new user
     * @param user User to register
     * @return true if registration successful, false otherwise
     */
    public boolean registerUser(User user) {
        // Validate user data
        if (user.getUsername() == null || user.getUsername().isEmpty() ||
            user.getPassword() == null || user.getPassword().isEmpty() ||
            user.getEmail() == null || user.getEmail().isEmpty() ||
            user.getFirstName() == null || user.getFirstName().isEmpty() ||
            user.getLastName() == null || user.getLastName().isEmpty()) {
            return false;
        }

        // Validate email format
        if (!ValidationUtil.isValidEmail(user.getEmail())) {
            return false;
        }

        // Validate username format
        if (!ValidationUtil.isValidUsername(user.getUsername())) {
            return false;
        }

        // Check if username already exists
        if (userDAO.getUserByUsername(user.getUsername()) != null) {
            return false;
        }

        // Check if email already exists
        if (userDAO.getUserByEmail(user.getEmail()) != null) {
            return false;
        }

        // Set default role if not specified
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("GUEST");
        }

        // Hash the password before storing
        String hashedPassword = PasswordUtil.hashPassword(user.getPassword());
        user.setPassword(hashedPassword);

        return userDAO.createUser(user);
    }

    /**
     * Authenticate a user
     * @param username Username to authenticate
     * @param password Password to authenticate
     * @return User object if authentication successful, null otherwise
     */
    public User authenticateUser(String username, String password) {
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            return null;
        }

        try {
            // Get user by username
            User user = userDAO.getUserForAuthentication(username);

            if (user == null) {
                System.out.println("No user found with username: " + username);
                return null;
            }

            System.out.println("Found user: " + user.getUsername() + ", class: " + user.getClass().getName());

            // Verify password
            if (PasswordUtil.verifyPassword(password, user.getPassword())) {
                // Use the adapter to ensure class compatibility
                return UserAdapter.adaptUser(user);
            }

            // For backward compatibility with non-hashed passwords
            // This should be removed after all passwords are migrated to hashed format
            if (password.equals(user.getPassword())) {
                // If plain text password matches, update it to hashed version
                String hashedPassword = PasswordUtil.hashPassword(password);
                user.setPassword(hashedPassword);
                userDAO.updateUser(user);
                // Use the adapter to ensure class compatibility
                return UserAdapter.adaptUser(user);
            }

            System.out.println("Password verification failed for user: " + username);
            return null;
        } catch (Exception e) {
            System.err.println("Error during authentication: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Get a user by ID
     * @param userId User ID to search for
     * @return User object if found, null otherwise
     */
    public User getUserById(int userId) {
        User user = userDAO.getUserById(userId);
        return UserAdapter.adaptUser(user);
    }

    /**
     * Get a user by username
     * @param username Username to search for
     * @return User object if found, null otherwise
     */
    public User getUserByUsername(String username) {
        User user = userDAO.getUserByUsername(username);
        return UserAdapter.adaptUser(user);
    }

    /**
     * Update a user
     * @param user User to update
     * @return true if update successful, false otherwise
     */
    public boolean updateUser(User user) {
        // Validate user data
        if (user.getUsername() == null || user.getUsername().isEmpty() ||
            user.getEmail() == null || user.getEmail().isEmpty() ||
            user.getFirstName() == null || user.getFirstName().isEmpty() ||
            user.getLastName() == null || user.getLastName().isEmpty()) {
            return false;
        }

        // Validate email format
        if (!ValidationUtil.isValidEmail(user.getEmail())) {
            return false;
        }

        // Validate username format
        if (!ValidationUtil.isValidUsername(user.getUsername())) {
            return false;
        }

        // Check if username already exists for a different user
        User existingUser = userDAO.getUserByUsername(user.getUsername());
        if (existingUser != null && existingUser.getUserId() != user.getUserId()) {
            return false;
        }

        // Check if email already exists for a different user
        existingUser = userDAO.getUserByEmail(user.getEmail());
        if (existingUser != null && existingUser.getUserId() != user.getUserId()) {
            return false;
        }

        return userDAO.updateUser(user);
    }

    /**
     * Update a user's password
     * @param userId User ID
     * @param currentPassword Current password
     * @param newPassword New password
     * @return true if password update successful, false otherwise
     */
    public boolean updatePassword(int userId, String currentPassword, String newPassword) {
        // Get user by ID
        User user = userDAO.getUserById(userId);

        if (user == null) {
            return false;
        }

        // Verify current password
        if (!PasswordUtil.verifyPassword(currentPassword, user.getPassword()) &&
            !currentPassword.equals(user.getPassword())) {
            return false;
        }

        // Check if new password is strong enough
        if (!PasswordUtil.isStrongPassword(newPassword)) {
            return false;
        }

        // Hash the new password
        String hashedPassword = PasswordUtil.hashPassword(newPassword);
        user.setPassword(hashedPassword);

        return userDAO.updateUser(user);
    }
}
