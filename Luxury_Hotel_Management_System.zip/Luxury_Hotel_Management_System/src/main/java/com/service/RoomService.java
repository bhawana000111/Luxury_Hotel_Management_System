package com.service;

import com.dao.RoomDAO;
import com.model.Room;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service class for room-related operations
 */
public class RoomService {
    private final RoomDAO roomDAO;

    public RoomService() {
        this.roomDAO = new RoomDAO();
    }

    /**
     * Get all rooms from the database
     * @return List of all rooms
     */
    public List<Room> getAllRooms() {
        List<Room> rooms = roomDAO.getAllRooms();

        // If database connection fails, return some sample rooms
        if (rooms.isEmpty()) {
            rooms.add(new Room("101", "STANDARD", new BigDecimal("100.00"), 2, "Standard room with basic amenities"));
            rooms.add(new Room("201", "DELUXE", new BigDecimal("200.00"), 2, "Deluxe room with premium amenities"));
            rooms.add(new Room("301", "SUITE", new BigDecimal("350.00"), 4, "Luxury suite with separate living area"));
            rooms.add(new Room("401", "PRESIDENTIAL", new BigDecimal("500.00"), 6, "Presidential suite with premium amenities and services"));
        }

        return rooms;
    }

    /**
     * Get a room by its ID
     * @param roomId The ID of the room to retrieve
     * @return The room with the specified ID, or null if not found
     */
    public Room getRoomById(int roomId) {
        return roomDAO.getRoomById(roomId);
    }

    /**
     * Get rooms by type
     * @param roomType Type of room to search for
     * @return List of rooms of the specified type
     */
    public List<Room> getRoomsByType(String roomType) {
        return roomDAO.getRoomsByType(roomType);
    }

    /**
     * Get rooms by price range
     * @param minPrice Minimum price
     * @param maxPrice Maximum price
     * @return List of rooms within the specified price range
     */
    public List<Room> getRoomsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        return roomDAO.getRoomsByPriceRange(minPrice, maxPrice);
    }

    /**
     * Get available rooms
     * @return List of available rooms
     */
    public List<Room> getAvailableRooms() {
        return roomDAO.getAvailableRooms();
    }

    /**
     * Update room availability
     * @param roomId Room ID to update
     * @param isAvailable New availability status
     * @return true if successful, false otherwise
     */
    public boolean updateRoomAvailability(int roomId, boolean isAvailable) {
        return roomDAO.updateRoomAvailability(roomId, isAvailable);
    }

    /**
     * Search rooms by criteria
     * @param roomType Room type (optional)
     * @param priceRange Price range (optional, format: "min-max" or "min+" for min and above)
     * @param capacity Capacity (optional)
     * @return List of rooms matching the criteria
     */
    public List<Room> searchRooms(String roomType, String priceRange, Integer capacity) {
        List<Room> rooms = getAllRooms();

        // Filter by room type if provided
        if (roomType != null && !roomType.isEmpty()) {
            rooms = rooms.stream()
                    .filter(room -> room.getRoomType().equals(roomType))
                    .collect(Collectors.toList());
        }

        // Filter by price range if provided
        if (priceRange != null && !priceRange.isEmpty()) {
            BigDecimal minPrice = null;
            BigDecimal maxPrice = null;

            if (priceRange.endsWith("+")) {
                // Format: "min+"
                String minStr = priceRange.substring(0, priceRange.length() - 1);
                try {
                    minPrice = new BigDecimal(minStr);
                } catch (NumberFormatException e) {
                    // Invalid price range, ignore it
                }
            } else if (priceRange.contains("-")) {
                // Format: "min-max"
                String[] parts = priceRange.split("-");
                try {
                    minPrice = new BigDecimal(parts[0]);
                    maxPrice = new BigDecimal(parts[1]);
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    // Invalid price range, ignore it
                }
            }

            if (minPrice != null) {
                BigDecimal finalMinPrice = minPrice;
                BigDecimal finalMaxPrice = maxPrice;

                rooms = rooms.stream()
                        .filter(room -> {
                            BigDecimal price = room.getPricePerNight();
                            if (finalMaxPrice != null) {
                                return price.compareTo(finalMinPrice) >= 0 && price.compareTo(finalMaxPrice) <= 0;
                            } else {
                                return price.compareTo(finalMinPrice) >= 0;
                            }
                        })
                        .collect(Collectors.toList());
            }
        }

        // Filter by capacity if provided
        if (capacity != null) {
            rooms = rooms.stream()
                    .filter(room -> room.getCapacity() >= capacity)
                    .collect(Collectors.toList());
        }

        return rooms;
    }
}
