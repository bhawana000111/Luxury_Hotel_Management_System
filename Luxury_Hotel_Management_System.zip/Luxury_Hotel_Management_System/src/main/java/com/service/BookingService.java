package com.service;

import com.dao.BookingDAO;
import com.dao.RoomDAO;
import com.model.Booking;
import com.model.Room;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Service class for booking-related operations
 */
public class BookingService {
    private final BookingDAO bookingDAO;
    private final RoomDAO roomDAO;
    
    public BookingService() {
        this.bookingDAO = new BookingDAO();
        this.roomDAO = new RoomDAO();
    }
    
    /**
     * Create a new booking
     * @param userId User ID making the booking
     * @param roomId Room ID being booked
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return Booking object if successful, null otherwise
     */
    public Booking createBooking(int userId, int roomId, Date checkInDate, Date checkOutDate) {
        // Check if room is available for the given dates
        if (!bookingDAO.isRoomAvailable(roomId, checkInDate, checkOutDate)) {
            return null;
        }
        
        // Get room details to calculate total price
        Room room = roomDAO.getRoomById(roomId);
        if (room == null) {
            return null;
        }
        
        // Calculate number of nights
        LocalDate checkIn = checkInDate.toLocalDate();
        LocalDate checkOut = checkOutDate.toLocalDate();
        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        
        if (nights <= 0) {
            return null; // Invalid date range
        }
        
        // Calculate total price
        BigDecimal totalPrice = room.getPricePerNight().multiply(BigDecimal.valueOf(nights));
        
        // Create booking object
        Booking booking = new Booking(userId, roomId, checkInDate, checkOutDate, totalPrice);
        
        // Save booking to database
        if (bookingDAO.createBooking(booking)) {
            return booking;
        }
        
        return null;
    }
    
    /**
     * Get a booking by ID
     * @param bookingId Booking ID to retrieve
     * @return Booking object if found, null otherwise
     */
    public Booking getBookingById(int bookingId) {
        return bookingDAO.getBookingById(bookingId);
    }
    
    /**
     * Get all bookings for a user
     * @param userId User ID to get bookings for
     * @return List of bookings for the user
     */
    public List<Booking> getBookingsByUserId(int userId) {
        return bookingDAO.getBookingsByUserId(userId);
    }
    
    /**
     * Get all bookings
     * @return List of all bookings
     */
    public List<Booking> getAllBookings() {
        return bookingDAO.getAllBookings();
    }
    
    /**
     * Update booking status
     * @param bookingId Booking ID to update
     * @param status New booking status
     * @return true if successful, false otherwise
     */
    public boolean updateBookingStatus(int bookingId, String status) {
        return bookingDAO.updateBookingStatus(bookingId, status);
    }
    
    /**
     * Cancel a booking
     * @param bookingId Booking ID to cancel
     * @return true if successful, false otherwise
     */
    public boolean cancelBooking(int bookingId) {
        return bookingDAO.cancelBooking(bookingId);
    }
    
    /**
     * Check if a room is available for the given date range
     * @param roomId Room ID to check
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return true if room is available, false otherwise
     */
    public boolean isRoomAvailable(int roomId, Date checkInDate, Date checkOutDate) {
        return bookingDAO.isRoomAvailable(roomId, checkInDate, checkOutDate);
    }
    
    /**
     * Get available rooms for the given date range
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return List of room IDs that are available
     */
    public List<Integer> getAvailableRoomIds(Date checkInDate, Date checkOutDate) {
        return bookingDAO.getAvailableRoomIds(checkInDate, checkOutDate);
    }
    
    /**
     * Calculate total price for a booking
     * @param roomId Room ID being booked
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return Total price for the booking
     */
    public BigDecimal calculateTotalPrice(int roomId, Date checkInDate, Date checkOutDate) {
        // Get room details
        Room room = roomDAO.getRoomById(roomId);
        if (room == null) {
            return BigDecimal.ZERO;
        }
        
        // Calculate number of nights
        LocalDate checkIn = checkInDate.toLocalDate();
        LocalDate checkOut = checkOutDate.toLocalDate();
        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        
        if (nights <= 0) {
            return BigDecimal.ZERO; // Invalid date range
        }
        
        // Calculate total price
        return room.getPricePerNight().multiply(BigDecimal.valueOf(nights));
    }
}
