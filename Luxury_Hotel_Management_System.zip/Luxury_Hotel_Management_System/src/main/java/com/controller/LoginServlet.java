package com.controller;

import com.model.User;
import com.service.UserService;
import com.util.SessionUtil;
import com.util.CookieUtil;
import com.util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

/**
 * Servlet for handling user login
 */
@WebServlet(name = "loginServlet", value = "/login")
public class LoginServlet extends HttpServlet {
    private final UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // If user is already logged in, redirect to appropriate dashboard
        if (SessionUtil.isLoggedIn(request)) {
            if (SessionUtil.isAdmin(request)) {
                response.sendRedirect(request.getContextPath() + "/admin/dashboard");
            } else {
                response.sendRedirect(request.getContextPath() + "/guest/dashboard");
            }
            return;
        }

        // Check for remember me cookie
        String rememberedUsername = CookieUtil.getCookieValue(request, "remember_user");
        String rememberedToken = CookieUtil.getCookieValue(request, "remember_token");

        if (rememberedUsername != null && rememberedToken != null) {
            // Attempt to authenticate with the remembered token
            User user = userService.getUserByUsername(rememberedUsername);

            if (user != null) {
                // In a real application, you would validate the token against a stored token in the database
                // For simplicity, we're just checking if the user exists and setting the session
                SessionUtil.setCurrentUser(request, user);

                // Redirect based on role
                if ("ADMIN".equals(user.getRole())) {
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                } else {
                    response.sendRedirect(request.getContextPath() + "/guest/dashboard");
                }
                return;
            } else {
                // Invalid remember me cookie, delete it
                CookieUtil.deleteRememberMeCookies(response);
            }
        }

        // Forward to login page
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String username = ValidationUtil.sanitizeInput(request.getParameter("username"));
            String password = request.getParameter("password"); // Don't sanitize passwords
            String rememberMe = request.getParameter("remember");

            // Validate input
            if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
                request.setAttribute("error", "Username and password are required");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                return;
            }

            // Authenticate user
            User user = userService.authenticateUser(username, password);

            if (user != null) {
                // Set user in session
                SessionUtil.setCurrentUser(request, user);

                // Handle remember me functionality
                if (rememberMe != null) {
                    // Generate a unique token for this user
                    String token = UUID.randomUUID().toString();

                    // In a real application, you would store this token in the database
                    // associated with the user for validation later

                    // Set remember me cookies
                    CookieUtil.setRememberMeCookie(response, user.getUsername(), token);
                }

                // Log successful login
                System.out.println("User logged in successfully: " + user.getUsername() + ", Role: " + user.getRole());

                try {
                    // Log user details for debugging
                    System.out.println("User authenticated successfully: " + user.getUsername());
                    System.out.println("User role: " + user.getRole());
                    System.out.println("User class: " + user.getClass().getName());

                    // Redirect based on role
                    if ("ADMIN".equals(user.getRole())) {
                        System.out.println("Redirecting to admin dashboard");
                        response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                    } else {
                        System.out.println("Redirecting to guest dashboard");
                        response.sendRedirect(request.getContextPath() + "/guest/dashboard");
                    }
                } catch (Exception e) {
                    System.err.println("Error redirecting after login: " + e.getMessage());
                    e.printStackTrace();
                    request.setAttribute("error", "Error during redirect: " + e.getMessage());
                    request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
                }
            } else {
                request.setAttribute("error", "Invalid username or password");
                request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error in LoginServlet.doPost: " + e.getMessage());
            e.printStackTrace();

            // Set error message and forward to login page
            request.setAttribute("error", "An error occurred during login. Please try again later.");
            request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
        }
    }
}
