package com.controller;

import com.model.User;
import com.service.UserService;
import com.util.ValidationUtil;
import com.util.PasswordUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet for handling user registration
 */
@WebServlet(name = "registerServlet", value = "/register")
public class RegisterServlet extends HttpServlet {
    private final UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to registration page
        request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters
        String username = ValidationUtil.sanitizeInput(request.getParameter("username"));
        String password = request.getParameter("password"); // Don't sanitize passwords
        String confirmPassword = request.getParameter("confirmPassword");
        String email = ValidationUtil.sanitizeInput(request.getParameter("email"));
        String firstName = ValidationUtil.sanitizeInput(request.getParameter("firstName"));
        String lastName = ValidationUtil.sanitizeInput(request.getParameter("lastName"));
        String phone = ValidationUtil.sanitizeInput(request.getParameter("phone"));
        String address = ValidationUtil.sanitizeInput(request.getParameter("address"));

        // Validate required fields
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty() ||
            confirmPassword == null || confirmPassword.trim().isEmpty() ||
            email == null || email.trim().isEmpty() ||
            firstName == null || firstName.trim().isEmpty() ||
            lastName == null || lastName.trim().isEmpty()) {

            request.setAttribute("error", "All required fields must be filled");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Validate username format
        if (!ValidationUtil.isValidUsername(username)) {
            request.setAttribute("error", "Username must be 3-20 characters and contain only letters, numbers, and underscores");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Validate email format
        if (!ValidationUtil.isValidEmail(email)) {
            request.setAttribute("error", "Please enter a valid email address");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Validate phone number if provided
        if (phone != null && !phone.trim().isEmpty() && !ValidationUtil.isValidPhone(phone)) {
            request.setAttribute("error", "Please enter a valid phone number (10-15 digits)");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            request.setAttribute("error", "Passwords do not match");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Check password strength
        if (!PasswordUtil.isStrongPassword(password)) {
            request.setAttribute("error", "Password must be at least 8 characters and include letters, numbers, and special characters");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
            return;
        }

        // Create user object
        User user = new User();
        user.setUsername(username);
        user.setPassword(password); // Will be hashed in UserService
        user.setEmail(email);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        user.setPhone(phone);
        user.setAddress(address);
        user.setRole("GUEST"); // Default role for new users

        // Register user
        boolean success = userService.registerUser(user);

        if (success) {
            // Redirect to login page with success message
            request.getSession().setAttribute("message", "Registration successful. Please login.");
            response.sendRedirect(request.getContextPath() + "/login");
        } else {
            request.setAttribute("error", "Registration failed. Username or email may already exist.");
            request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
        }
    }
}
