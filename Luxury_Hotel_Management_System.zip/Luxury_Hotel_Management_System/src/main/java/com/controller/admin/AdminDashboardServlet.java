package com.controller.admin;

import com.model.User;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet for handling admin dashboard
 */
@WebServlet(name = "adminDashboardServlet", value = "/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Verify user is logged in and is an admin
            User currentUser = SessionUtil.getCurrentUser(request);
            if (currentUser == null) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            if (!"ADMIN".equals(currentUser.getRole())) {
                response.sendRedirect(request.getContextPath() + "/guest/dashboard");
                return;
            }

            // Forward to admin dashboard page
            request.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            // Log the error
            System.err.println("Error in AdminDashboardServlet: " + e.getMessage());
            e.printStackTrace();

            // Set error message and redirect to error page
            request.setAttribute("errorMessage", "An error occurred while loading the dashboard. Please try again later.");
            request.getRequestDispatcher("/WEB-INF/views/error/500.jsp").forward(request, response);
        }
    }
}
