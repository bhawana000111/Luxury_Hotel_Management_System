package com.controller.guest;

import com.model.User;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet for handling guest dashboard
 */
@WebServlet(name = "guestDashboardServlet", value = "/guest/dashboard")
public class GuestDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Verify user is logged in and is a guest
            User currentUser = SessionUtil.getCurrentUser(request);
            if (currentUser == null) {
                response.sendRedirect(request.getContextPath() + "/login");
                return;
            }

            // Forward to guest dashboard page
            request.getRequestDispatcher("/WEB-INF/views/guest/dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            // Log the error
            System.err.println("Error in GuestDashboardServlet: " + e.getMessage());
            e.printStackTrace();

            // Set error message and redirect to error page
            request.setAttribute("errorMessage", "An error occurred while loading the dashboard. Please try again later.");
            request.getRequestDispatcher("/WEB-INF/views/error/500.jsp").forward(request, response);
        }
    }
}
