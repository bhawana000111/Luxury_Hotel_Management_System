package com.controller;

import com.model.User;
import com.service.UserService;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Servlet for diagnostic login
 */
@WebServlet(name = "diagnosticLoginServlet", value = "/diagnostic-login")
public class DiagnosticLoginServlet extends HttpServlet {
    
    private UserService userService;
    
    @Override
    public void init() throws ServletException {
        userService = new UserService();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to diagnostic login page
        request.getRequestDispatcher("/diagnostic-login.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try {
            // Authenticate user
            User user = userService.authenticateUser(username, password);
            
            if (user != null) {
                // Log user details
                System.out.println("Diagnostic login successful for user: " + username);
                System.out.println("User class: " + user.getClass().getName());
                
                // Create a new session to avoid conflicts
                HttpSession oldSession = request.getSession(false);
                if (oldSession != null) {
                    oldSession.invalidate();
                }
                
                HttpSession newSession = request.getSession(true);
                
                // Set user in session directly
                newSession.setAttribute("currentUser", user);
                
                // Set success message
                request.setAttribute("message", "Login successful! User class: " + user.getClass().getName());
                
                // Forward back to diagnostic login page
                request.getRequestDispatcher("/diagnostic-login.jsp").forward(request, response);
            } else {
                // Set error message
                request.setAttribute("error", "Invalid username or password");
                
                // Forward back to diagnostic login page
                request.getRequestDispatcher("/diagnostic-login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Log the error
            System.err.println("Error during diagnostic login: " + e.getMessage());
            e.printStackTrace();
            
            // Set error message
            request.setAttribute("error", "Error during login: " + e.getMessage());
            
            // Forward back to diagnostic login page
            request.getRequestDispatcher("/diagnostic-login.jsp").forward(request, response);
        }
    }
}
