package com.controller;

import com.model.Booking;
import com.model.Room;
import com.model.User;
import com.service.BookingService;
import com.service.RoomService;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * Servlet for handling booking page and booking process
 */
@WebServlet(name = "bookingServlet", value = "/booking")
public class BookingServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();
    private final RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        User currentUser = SessionUtil.getCurrentUser(request);
        if (currentUser == null) {
            // Redirect to login page with return URL
            response.sendRedirect(request.getContextPath() + "/login?redirect=booking");
            return;
        }

        // Get room ID if provided
        String roomIdParam = request.getParameter("roomId");
        if (roomIdParam != null && !roomIdParam.isEmpty()) {
            try {
                int roomId = Integer.parseInt(roomIdParam);
                Room room = roomService.getRoomById(roomId);
                if (room != null) {
                    request.setAttribute("room", room);
                    request.setAttribute("roomId", roomId);
                }
            } catch (NumberFormatException e) {
                // Invalid room ID, ignore it
            }
        }

        // Get check-in and check-out dates if provided
        String checkIn = request.getParameter("checkIn");
        String checkOut = request.getParameter("checkOut");

        if (checkIn != null && !checkIn.isEmpty()) {
            request.setAttribute("checkIn", checkIn);
        }

        if (checkOut != null && !checkOut.isEmpty()) {
            request.setAttribute("checkOut", checkOut);
        }

        // Forward to booking page
        request.getRequestDispatcher("/WEB-INF/views/booking.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        User currentUser = SessionUtil.getCurrentUser(request);
        if (currentUser == null) {
            // Redirect to login page with return URL
            response.sendRedirect(request.getContextPath() + "/login?redirect=booking");
            return;
        }

        // Get form parameters
        String roomIdParam = request.getParameter("roomId");
        String checkInParam = request.getParameter("checkIn");
        String checkOutParam = request.getParameter("checkOut");
        String adultsParam = request.getParameter("adults");
        String childrenParam = request.getParameter("children");
        String specialRequestsParam = request.getParameter("specialRequests");

        // Validate required parameters
        if (roomIdParam == null || roomIdParam.isEmpty() ||
            checkInParam == null || checkInParam.isEmpty() ||
            checkOutParam == null || checkOutParam.isEmpty()) {

            request.setAttribute("error", "Please fill in all required fields");
            doGet(request, response);
            return;
        }

        try {
            // Parse parameters
            int roomId = Integer.parseInt(roomIdParam);
            LocalDate checkInDate = LocalDate.parse(checkInParam);
            LocalDate checkOutDate = LocalDate.parse(checkOutParam);

            // Validate dates
            if (checkInDate.isBefore(LocalDate.now())) {
                request.setAttribute("error", "Check-in date cannot be in the past");
                doGet(request, response);
                return;
            }

            if (checkOutDate.isBefore(checkInDate) || checkOutDate.isEqual(checkInDate)) {
                request.setAttribute("error", "Check-out date must be after check-in date");
                doGet(request, response);
                return;
            }

            // Convert LocalDate to java.sql.Date
            Date sqlCheckInDate = Date.valueOf(checkInDate);
            Date sqlCheckOutDate = Date.valueOf(checkOutDate);

            // Check if room is available for the selected dates
            if (!bookingService.isRoomAvailable(roomId, sqlCheckInDate, sqlCheckOutDate)) {
                request.setAttribute("error", "The selected room is not available for the chosen dates");
                doGet(request, response);
                return;
            }

            // Create booking
            Booking booking = bookingService.createBooking(
                currentUser.getUserId(),
                roomId,
                sqlCheckInDate,
                sqlCheckOutDate
            );

            if (booking != null) {
                // Booking successful, redirect to confirmation page
                response.sendRedirect(request.getContextPath() + "/booking/confirmation?bookingId=" + booking.getBookingId());
            } else {
                // Booking failed
                request.setAttribute("error", "Failed to create booking. Please try again.");
                doGet(request, response);
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid room ID");
            doGet(request, response);
        } catch (DateTimeParseException e) {
            request.setAttribute("error", "Invalid date format");
            doGet(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "An error occurred: " + e.getMessage());
            doGet(request, response);
        }
    }
}
