package com.controller;

import com.model.Booking;
import com.model.Room;
import com.model.User;
import com.service.BookingService;
import com.service.RoomService;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet for handling booking confirmation page
 */
@WebServlet(name = "bookingConfirmationServlet", value = "/booking/confirmation")
public class BookingConfirmationServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();
    private final RoomService roomService = new RoomService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        User currentUser = SessionUtil.getCurrentUser(request);
        if (currentUser == null) {
            // Redirect to login page
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        
        // Get booking ID from request
        String bookingIdParam = request.getParameter("bookingId");
        if (bookingIdParam == null || bookingIdParam.isEmpty()) {
            // No booking ID provided, redirect to booking page
            response.sendRedirect(request.getContextPath() + "/booking");
            return;
        }
        
        try {
            int bookingId = Integer.parseInt(bookingIdParam);
            
            // Get booking details
            Booking booking = bookingService.getBookingById(bookingId);
            
            if (booking == null) {
                // Booking not found
                request.setAttribute("error", "Booking not found");
                request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
                return;
            }
            
            // Check if the booking belongs to the current user or if the user is an admin
            if (booking.getUserId() != currentUser.getUserId() && !SessionUtil.isAdmin(request)) {
                // Unauthorized access
                request.setAttribute("error", "You are not authorized to view this booking");
                request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
                return;
            }
            
            // Get room details
            Room room = roomService.getRoomById(booking.getRoomId());
            
            // Set attributes for the view
            request.setAttribute("booking", booking);
            request.setAttribute("room", room);
            
            // Forward to confirmation page
            request.getRequestDispatcher("/WEB-INF/views/booking-confirmation.jsp").forward(request, response);
            
        } catch (NumberFormatException e) {
            // Invalid booking ID
            request.setAttribute("error", "Invalid booking ID");
            request.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
        }
    }
}
