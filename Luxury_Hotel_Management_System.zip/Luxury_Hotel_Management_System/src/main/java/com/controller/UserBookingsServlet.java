package com.controller;

import com.model.Booking;
import com.model.User;
import com.service.BookingService;
import com.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Servlet for handling user bookings page
 */
@WebServlet(name = "userBookingsServlet", value = "/guest/bookings")
public class UserBookingsServlet extends HttpServlet {
    private final BookingService bookingService = new BookingService();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        User currentUser = SessionUtil.getCurrentUser(request);
        if (currentUser == null) {
            // Redirect to login page
            response.sendRedirect(request.getContextPath() + "/login?redirect=guest/bookings");
            return;
        }
        
        // Get user's bookings
        List<Booking> bookings = bookingService.getBookingsByUserId(currentUser.getUserId());
        
        // Set attributes for the view
        request.setAttribute("bookings", bookings);
        
        // Forward to user bookings page
        request.getRequestDispatcher("/WEB-INF/views/guest/bookings.jsp").forward(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Check if user is logged in
        User currentUser = SessionUtil.getCurrentUser(request);
        if (currentUser == null) {
            // Redirect to login page
            response.sendRedirect(request.getContextPath() + "/login?redirect=guest/bookings");
            return;
        }
        
        // Get action and booking ID
        String action = request.getParameter("action");
        String bookingIdParam = request.getParameter("bookingId");
        
        if (action == null || action.isEmpty() || bookingIdParam == null || bookingIdParam.isEmpty()) {
            // Missing parameters
            request.setAttribute("error", "Missing parameters");
            doGet(request, response);
            return;
        }
        
        try {
            int bookingId = Integer.parseInt(bookingIdParam);
            
            // Get booking details
            Booking booking = bookingService.getBookingById(bookingId);
            
            if (booking == null) {
                // Booking not found
                request.setAttribute("error", "Booking not found");
                doGet(request, response);
                return;
            }
            
            // Check if the booking belongs to the current user
            if (booking.getUserId() != currentUser.getUserId()) {
                // Unauthorized access
                request.setAttribute("error", "You are not authorized to modify this booking");
                doGet(request, response);
                return;
            }
            
            // Process action
            if ("cancel".equals(action)) {
                // Cancel booking
                boolean success = bookingService.cancelBooking(bookingId);
                
                if (success) {
                    request.setAttribute("message", "Booking cancelled successfully");
                } else {
                    request.setAttribute("error", "Failed to cancel booking");
                }
            } else {
                // Unknown action
                request.setAttribute("error", "Unknown action");
            }
            
            // Redirect to user bookings page
            doGet(request, response);
            
        } catch (NumberFormatException e) {
            // Invalid booking ID
            request.setAttribute("error", "Invalid booking ID");
            doGet(request, response);
        }
    }
}
