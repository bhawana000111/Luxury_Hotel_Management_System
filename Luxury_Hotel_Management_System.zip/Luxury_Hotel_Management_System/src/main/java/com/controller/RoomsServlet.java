package com.controller;

import com.model.Room;
import com.service.RoomService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Servlet for handling rooms listing and details
 */
@WebServlet(name = "roomsServlet", value = "/rooms")
public class RoomsServlet extends HttpServlet {

    private final RoomService roomService = new RoomService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get search parameters
        String checkIn = request.getParameter("checkIn");
        String checkOut = request.getParameter("checkOut");
        String roomType = request.getParameter("roomType");
        String priceRange = request.getParameter("priceRange");
        String guestsParam = request.getParameter("guests");

        // Set search parameters as request attributes for form persistence
        request.setAttribute("checkIn", checkIn);
        request.setAttribute("checkOut", checkOut);
        request.setAttribute("roomType", roomType);
        request.setAttribute("priceRange", priceRange);
        request.setAttribute("guests", guestsParam);

        // Parse guests parameter
        Integer guests = null;
        if (guestsParam != null && !guestsParam.isEmpty() && !guestsParam.equals("5+")) {
            try {
                guests = Integer.parseInt(guestsParam);
            } catch (NumberFormatException e) {
                // Invalid guests parameter, ignore it
            }
        } else if ("5+".equals(guestsParam)) {
            guests = 5; // 5 or more
        }

        List<Room> rooms;

        // If search parameters are provided, filter rooms
        if ((roomType != null && !roomType.isEmpty()) ||
            (priceRange != null && !priceRange.isEmpty()) ||
            guests != null) {

            rooms = roomService.searchRooms(roomType, priceRange, guests);
            System.out.println("Filtered rooms: " + rooms.size());
        } else {
            // Otherwise, get all rooms
            rooms = roomService.getAllRooms();
            System.out.println("All rooms: " + rooms.size());
        }

        // Set rooms as request attribute
        request.setAttribute("rooms", rooms);

        // Forward to rooms page
        request.getRequestDispatcher("/WEB-INF/views/rooms.jsp").forward(request, response);
    }
}
