package com.dao;

import com.model.Billing;
import com.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Billing entity
 */
public class BillingDAO {
    
    /**
     * Create a new billing record in the database
     * @param billing Billing object to create
     * @return true if successful, false otherwise
     */
    public boolean createBilling(Billing billing) {
        String sql = "INSERT INTO billing (booking_id, total_amount, payment_status, payment_date, " +
                     "payment_method, transaction_id, notes) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, billing.getBookingId());
            stmt.setBigDecimal(2, billing.getTotalAmount());
            stmt.setString(3, billing.getPaymentStatus());
            
            if (billing.getPaymentDate() != null) {
                stmt.setTimestamp(4, new Timestamp(billing.getPaymentDate().getTime()));
            } else {
                stmt.setNull(4, Types.TIMESTAMP);
            }
            
            stmt.setString(5, billing.getPaymentMethod());
            stmt.setString(6, billing.getTransactionId());
            stmt.setString(7, billing.getNotes());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the generated bill ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    billing.setBillId(rs.getInt(1));
                }
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating billing: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get a billing record by ID
     * @param billId Bill ID to search for
     * @return Billing object if found, null otherwise
     */
    public Billing getBillingById(int billId) {
        String sql = "SELECT b.*, bk.booking_id as booking_reference, " +
                     "CONCAT(u.first_name, ' ', u.last_name) as guest_name " +
                     "FROM billing b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN users u ON bk.user_id = u.user_id " +
                     "WHERE b.bill_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, billId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Billing billing = extractBillingFromResultSet(rs);
                billing.setBookingReference(rs.getString("booking_reference"));
                billing.setGuestName(rs.getString("guest_name"));
                return billing;
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting billing by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get billing records by booking ID
     * @param bookingId Booking ID to search for
     * @return List of billing records for the booking
     */
    public List<Billing> getBillingsByBookingId(int bookingId) {
        List<Billing> billings = new ArrayList<>();
        String sql = "SELECT b.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name " +
                     "FROM billing b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN users u ON bk.user_id = u.user_id " +
                     "WHERE b.booking_id = ? " +
                     "ORDER BY b.created_at DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Billing billing = extractBillingFromResultSet(rs);
                billing.setBookingReference(String.valueOf(bookingId));
                billing.setGuestName(rs.getString("guest_name"));
                billings.add(billing);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting billings by booking ID: " + e.getMessage());
        }
        
        return billings;
    }
    
    /**
     * Get all billing records
     * @return List of all billing records
     */
    public List<Billing> getAllBillings() {
        List<Billing> billings = new ArrayList<>();
        String sql = "SELECT b.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name " +
                     "FROM billing b " +
                     "JOIN bookings bk ON b.booking_id = bk.booking_id " +
                     "JOIN users u ON bk.user_id = u.user_id " +
                     "ORDER BY b.created_at DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Billing billing = extractBillingFromResultSet(rs);
                billing.setBookingReference(String.valueOf(billing.getBookingId()));
                billing.setGuestName(rs.getString("guest_name"));
                billings.add(billing);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all billings: " + e.getMessage());
        }
        
        return billings;
    }
    
    /**
     * Update a billing record
     * @param billing Billing object to update
     * @return true if successful, false otherwise
     */
    public boolean updateBilling(Billing billing) {
        String sql = "UPDATE billing SET payment_status = ?, payment_date = ?, " +
                     "payment_method = ?, transaction_id = ?, notes = ? WHERE bill_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, billing.getPaymentStatus());
            
            if (billing.getPaymentDate() != null) {
                stmt.setTimestamp(2, new Timestamp(billing.getPaymentDate().getTime()));
            } else {
                stmt.setNull(2, Types.TIMESTAMP);
            }
            
            stmt.setString(3, billing.getPaymentMethod());
            stmt.setString(4, billing.getTransactionId());
            stmt.setString(5, billing.getNotes());
            stmt.setInt(6, billing.getBillId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating billing: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Update billing payment status
     * @param billId Bill ID to update
     * @param paymentStatus New payment status
     * @return true if successful, false otherwise
     */
    public boolean updatePaymentStatus(int billId, String paymentStatus) {
        String sql = "UPDATE billing SET payment_status = ?, " +
                     "payment_date = ? WHERE bill_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, paymentStatus);
            
            if ("PAID".equals(paymentStatus)) {
                stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            } else {
                stmt.setNull(2, Types.TIMESTAMP);
            }
            
            stmt.setInt(3, billId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete a billing record
     * @param billId Bill ID to delete
     * @return true if successful, false otherwise
     */
    public boolean deleteBilling(int billId) {
        String sql = "DELETE FROM billing WHERE bill_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, billId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting billing: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Extract a Billing object from a ResultSet
     * @param rs ResultSet containing billing data
     * @return Billing object
     * @throws SQLException if a database access error occurs
     */
    private Billing extractBillingFromResultSet(ResultSet rs) throws SQLException {
        Billing billing = new Billing();
        billing.setBillId(rs.getInt("bill_id"));
        billing.setBookingId(rs.getInt("booking_id"));
        billing.setTotalAmount(rs.getBigDecimal("total_amount"));
        billing.setPaymentStatus(rs.getString("payment_status"));
        billing.setPaymentDate(rs.getTimestamp("payment_date"));
        billing.setPaymentMethod(rs.getString("payment_method"));
        billing.setTransactionId(rs.getString("transaction_id"));
        billing.setNotes(rs.getString("notes"));
        billing.setCreatedAt(rs.getTimestamp("created_at"));
        billing.setUpdatedAt(rs.getTimestamp("updated_at"));
        return billing;
    }
}
