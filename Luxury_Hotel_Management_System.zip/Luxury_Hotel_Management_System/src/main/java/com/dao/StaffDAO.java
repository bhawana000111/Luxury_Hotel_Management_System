package com.dao;

import com.model.Staff;
import com.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Staff entity
 */
public class StaffDAO {
    
    /**
     * Create a new staff member in the database
     * @param staff Staff object to create
     * @return true if successful, false otherwise
     */
    public boolean createStaff(Staff staff) {
        String sql = "INSERT INTO staff (full_name, email, phone, staff_role, hire_date, salary, is_active) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, staff.getFullName());
            stmt.setString(2, staff.getEmail());
            stmt.setString(3, staff.getPhone());
            stmt.setString(4, staff.getStaffRole());
            stmt.setDate(5, staff.getHireDate());
            stmt.setBigDecimal(6, staff.getSalary());
            stmt.setBoolean(7, staff.isActive());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the generated staff ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    staff.setStaffId(rs.getInt(1));
                }
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating staff: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get a staff member by ID
     * @param staffId Staff ID to search for
     * @return Staff object if found, null otherwise
     */
    public Staff getStaffById(int staffId) {
        String sql = "SELECT * FROM staff WHERE staff_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, staffId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractStaffFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting staff by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get a staff member by email
     * @param email Email to search for
     * @return Staff object if found, null otherwise
     */
    public Staff getStaffByEmail(String email) {
        String sql = "SELECT * FROM staff WHERE email = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractStaffFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting staff by email: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get all staff members
     * @return List of all staff members
     */
    public List<Staff> getAllStaff() {
        List<Staff> staffList = new ArrayList<>();
        String sql = "SELECT * FROM staff ORDER BY full_name";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                staffList.add(extractStaffFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all staff: " + e.getMessage());
        }
        
        return staffList;
    }
    
    /**
     * Get staff members by role
     * @param role Role to search for
     * @return List of staff members with the specified role
     */
    public List<Staff> getStaffByRole(String role) {
        List<Staff> staffList = new ArrayList<>();
        String sql = "SELECT * FROM staff WHERE staff_role = ? ORDER BY full_name";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, role);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                staffList.add(extractStaffFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting staff by role: " + e.getMessage());
        }
        
        return staffList;
    }
    
    /**
     * Update a staff member
     * @param staff Staff object to update
     * @return true if successful, false otherwise
     */
    public boolean updateStaff(Staff staff) {
        String sql = "UPDATE staff SET full_name = ?, email = ?, phone = ?, staff_role = ?, " +
                     "hire_date = ?, salary = ?, is_active = ? WHERE staff_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, staff.getFullName());
            stmt.setString(2, staff.getEmail());
            stmt.setString(3, staff.getPhone());
            stmt.setString(4, staff.getStaffRole());
            stmt.setDate(5, staff.getHireDate());
            stmt.setBigDecimal(6, staff.getSalary());
            stmt.setBoolean(7, staff.isActive());
            stmt.setInt(8, staff.getStaffId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating staff: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete a staff member
     * @param staffId Staff ID to delete
     * @return true if successful, false otherwise
     */
    public boolean deleteStaff(int staffId) {
        String sql = "DELETE FROM staff WHERE staff_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, staffId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting staff: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Extract a Staff object from a ResultSet
     * @param rs ResultSet containing staff data
     * @return Staff object
     * @throws SQLException if a database access error occurs
     */
    private Staff extractStaffFromResultSet(ResultSet rs) throws SQLException {
        Staff staff = new Staff();
        staff.setStaffId(rs.getInt("staff_id"));
        staff.setFullName(rs.getString("full_name"));
        staff.setEmail(rs.getString("email"));
        staff.setPhone(rs.getString("phone"));
        staff.setStaffRole(rs.getString("staff_role"));
        staff.setHireDate(rs.getDate("hire_date"));
        staff.setSalary(rs.getBigDecimal("salary"));
        staff.setActive(rs.getBoolean("is_active"));
        staff.setCreatedAt(rs.getTimestamp("created_at"));
        staff.setUpdatedAt(rs.getTimestamp("updated_at"));
        return staff;
    }
}
