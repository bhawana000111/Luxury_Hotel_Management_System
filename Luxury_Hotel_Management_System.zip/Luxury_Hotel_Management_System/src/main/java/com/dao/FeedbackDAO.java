package com.dao;

import com.model.Feedback;
import com.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Feedback entity
 */
public class FeedbackDAO {
    
    /**
     * Create a new feedback in the database
     * @param feedback Feedback object to create
     * @return true if successful, false otherwise
     */
    public boolean createFeedback(Feedback feedback) {
        String sql = "INSERT INTO feedback (user_id, booking_id, comment, rating, is_published) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, feedback.getUserId());
            
            if (feedback.getBookingId() != null) {
                stmt.setInt(2, feedback.getBookingId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            
            stmt.setString(3, feedback.getComment());
            stmt.setInt(4, feedback.getRating());
            stmt.setBoolean(5, feedback.isPublished());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the generated feedback ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    feedback.setFeedbackId(rs.getInt(1));
                }
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating feedback: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get a feedback by ID
     * @param feedbackId Feedback ID to search for
     * @return Feedback object if found, null otherwise
     */
    public Feedback getFeedbackById(int feedbackId) {
        String sql = "SELECT f.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name, " +
                     "r.room_number " +
                     "FROM feedback f " +
                     "JOIN users u ON f.user_id = u.user_id " +
                     "LEFT JOIN bookings b ON f.booking_id = b.booking_id " +
                     "LEFT JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE f.feedback_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, feedbackId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Feedback feedback = extractFeedbackFromResultSet(rs);
                feedback.setGuestName(rs.getString("guest_name"));
                feedback.setRoomNumber(rs.getString("room_number"));
                return feedback;
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting feedback by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get all feedback for a user
     * @param userId User ID to get feedback for
     * @return List of feedback for the user
     */
    public List<Feedback> getFeedbackByUserId(int userId) {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT f.*, r.room_number " +
                     "FROM feedback f " +
                     "LEFT JOIN bookings b ON f.booking_id = b.booking_id " +
                     "LEFT JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE f.user_id = ? " +
                     "ORDER BY f.date_submitted DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Feedback feedback = extractFeedbackFromResultSet(rs);
                feedback.setRoomNumber(rs.getString("room_number"));
                feedbackList.add(feedback);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting feedback by user ID: " + e.getMessage());
        }
        
        return feedbackList;
    }
    
    /**
     * Get feedback by booking ID
     * @param bookingId Booking ID to get feedback for
     * @return Feedback object if found, null otherwise
     */
    public Feedback getFeedbackByBookingId(int bookingId) {
        String sql = "SELECT f.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name, " +
                     "r.room_number " +
                     "FROM feedback f " +
                     "JOIN users u ON f.user_id = u.user_id " +
                     "LEFT JOIN bookings b ON f.booking_id = b.booking_id " +
                     "LEFT JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE f.booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Feedback feedback = extractFeedbackFromResultSet(rs);
                feedback.setGuestName(rs.getString("guest_name"));
                feedback.setRoomNumber(rs.getString("room_number"));
                return feedback;
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting feedback by booking ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get all published feedback
     * @return List of published feedback
     */
    public List<Feedback> getPublishedFeedback() {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT f.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name, " +
                     "r.room_number " +
                     "FROM feedback f " +
                     "JOIN users u ON f.user_id = u.user_id " +
                     "LEFT JOIN bookings b ON f.booking_id = b.booking_id " +
                     "LEFT JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE f.is_published = TRUE " +
                     "ORDER BY f.date_submitted DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Feedback feedback = extractFeedbackFromResultSet(rs);
                feedback.setGuestName(rs.getString("guest_name"));
                feedback.setRoomNumber(rs.getString("room_number"));
                feedbackList.add(feedback);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting published feedback: " + e.getMessage());
        }
        
        return feedbackList;
    }
    
    /**
     * Get all feedback
     * @return List of all feedback
     */
    public List<Feedback> getAllFeedback() {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT f.*, CONCAT(u.first_name, ' ', u.last_name) as guest_name, " +
                     "r.room_number " +
                     "FROM feedback f " +
                     "JOIN users u ON f.user_id = u.user_id " +
                     "LEFT JOIN bookings b ON f.booking_id = b.booking_id " +
                     "LEFT JOIN rooms r ON b.room_id = r.room_id " +
                     "ORDER BY f.date_submitted DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Feedback feedback = extractFeedbackFromResultSet(rs);
                feedback.setGuestName(rs.getString("guest_name"));
                feedback.setRoomNumber(rs.getString("room_number"));
                feedbackList.add(feedback);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all feedback: " + e.getMessage());
        }
        
        return feedbackList;
    }
    
    /**
     * Update a feedback
     * @param feedback Feedback object to update
     * @return true if successful, false otherwise
     */
    public boolean updateFeedback(Feedback feedback) {
        String sql = "UPDATE feedback SET comment = ?, rating = ?, is_published = ? " +
                     "WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, feedback.getComment());
            stmt.setInt(2, feedback.getRating());
            stmt.setBoolean(3, feedback.isPublished());
            stmt.setInt(4, feedback.getFeedbackId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating feedback: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Add staff response to feedback
     * @param feedbackId Feedback ID to respond to
     * @param staffResponse Response text
     * @return true if successful, false otherwise
     */
    public boolean addStaffResponse(int feedbackId, String staffResponse) {
        String sql = "UPDATE feedback SET staff_response = ?, response_date = ? " +
                     "WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, staffResponse);
            stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            stmt.setInt(3, feedbackId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error adding staff response: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Toggle feedback publication status
     * @param feedbackId Feedback ID to toggle
     * @param isPublished New publication status
     * @return true if successful, false otherwise
     */
    public boolean togglePublicationStatus(int feedbackId, boolean isPublished) {
        String sql = "UPDATE feedback SET is_published = ? WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBoolean(1, isPublished);
            stmt.setInt(2, feedbackId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error toggling publication status: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Delete a feedback
     * @param feedbackId Feedback ID to delete
     * @return true if successful, false otherwise
     */
    public boolean deleteFeedback(int feedbackId) {
        String sql = "DELETE FROM feedback WHERE feedback_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, feedbackId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting feedback: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Extract a Feedback object from a ResultSet
     * @param rs ResultSet containing feedback data
     * @return Feedback object
     * @throws SQLException if a database access error occurs
     */
    private Feedback extractFeedbackFromResultSet(ResultSet rs) throws SQLException {
        Feedback feedback = new Feedback();
        feedback.setFeedbackId(rs.getInt("feedback_id"));
        feedback.setUserId(rs.getInt("user_id"));
        
        int bookingId = rs.getInt("booking_id");
        if (!rs.wasNull()) {
            feedback.setBookingId(bookingId);
        }
        
        feedback.setComment(rs.getString("comment"));
        feedback.setRating(rs.getInt("rating"));
        feedback.setDateSubmitted(rs.getTimestamp("date_submitted"));
        feedback.setPublished(rs.getBoolean("is_published"));
        feedback.setStaffResponse(rs.getString("staff_response"));
        feedback.setResponseDate(rs.getTimestamp("response_date"));
        feedback.setCreatedAt(rs.getTimestamp("created_at"));
        feedback.setUpdatedAt(rs.getTimestamp("updated_at"));
        return feedback;
    }
}
