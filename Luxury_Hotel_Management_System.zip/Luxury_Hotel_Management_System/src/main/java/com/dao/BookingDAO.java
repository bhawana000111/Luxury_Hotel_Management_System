package com.dao;

import com.model.Booking;
import com.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Booking entity
 */
public class BookingDAO {
    
    /**
     * Create a new booking in the database
     * @param booking Booking object to create
     * @return true if successful, false otherwise
     */
    public boolean createBooking(Booking booking) {
        String sql = "INSERT INTO bookings (user_id, room_id, check_in_date, check_out_date, total_price, booking_status) " +
                     "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, booking.getUserId());
            stmt.setInt(2, booking.getRoomId());
            stmt.setDate(3, booking.getCheckInDate());
            stmt.setDate(4, booking.getCheckOutDate());
            stmt.setBigDecimal(5, booking.getTotalPrice());
            stmt.setString(6, booking.getBookingStatus());
            
            int rowsAffected = stmt.executeUpdate();
            
            if (rowsAffected > 0) {
                // Get the generated booking ID
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    booking.setBookingId(rs.getInt(1));
                }
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error creating booking: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get a booking by ID
     * @param bookingId Booking ID to search for
     * @return Booking object if found, null otherwise
     */
    public Booking getBookingById(int bookingId) {
        String sql = "SELECT b.*, u.username, r.room_number " +
                     "FROM bookings b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, bookingId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Booking booking = extractBookingFromResultSet(rs);
                booking.setUsername(rs.getString("username"));
                booking.setRoomNumber(rs.getString("room_number"));
                return booking;
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting booking by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get all bookings for a user
     * @param userId User ID to get bookings for
     * @return List of bookings for the user
     */
    public List<Booking> getBookingsByUserId(int userId) {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, u.username, r.room_number " +
                     "FROM bookings b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.user_id = ? " +
                     "ORDER BY b.check_in_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Booking booking = extractBookingFromResultSet(rs);
                booking.setUsername(rs.getString("username"));
                booking.setRoomNumber(rs.getString("room_number"));
                bookings.add(booking);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting bookings by user ID: " + e.getMessage());
        }
        
        return bookings;
    }
    
    /**
     * Get all bookings
     * @return List of all bookings
     */
    public List<Booking> getAllBookings() {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT b.*, u.username, r.room_number " +
                     "FROM bookings b " +
                     "JOIN users u ON b.user_id = u.user_id " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "ORDER BY b.check_in_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Booking booking = extractBookingFromResultSet(rs);
                booking.setUsername(rs.getString("username"));
                booking.setRoomNumber(rs.getString("room_number"));
                bookings.add(booking);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all bookings: " + e.getMessage());
        }
        
        return bookings;
    }
    
    /**
     * Update booking status
     * @param bookingId Booking ID to update
     * @param status New booking status
     * @return true if successful, false otherwise
     */
    public boolean updateBookingStatus(int bookingId, String status) {
        String sql = "UPDATE bookings SET booking_status = ? WHERE booking_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, bookingId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating booking status: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Cancel a booking
     * @param bookingId Booking ID to cancel
     * @return true if successful, false otherwise
     */
    public boolean cancelBooking(int bookingId) {
        return updateBookingStatus(bookingId, "CANCELLED");
    }
    
    /**
     * Check if a room is available for the given date range
     * @param roomId Room ID to check
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return true if room is available, false otherwise
     */
    public boolean isRoomAvailable(int roomId, Date checkInDate, Date checkOutDate) {
        String sql = "SELECT COUNT(*) FROM bookings " +
                     "WHERE room_id = ? AND booking_status != 'CANCELLED' " +
                     "AND ((check_in_date <= ? AND check_out_date > ?) " +
                     "OR (check_in_date < ? AND check_out_date >= ?) " +
                     "OR (check_in_date >= ? AND check_out_date <= ?))";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, roomId);
            stmt.setDate(2, checkOutDate);
            stmt.setDate(3, checkInDate);
            stmt.setDate(4, checkOutDate);
            stmt.setDate(5, checkInDate);
            stmt.setDate(6, checkInDate);
            stmt.setDate(7, checkOutDate);
            
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0;
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking room availability: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Get available rooms for the given date range
     * @param checkInDate Check-in date
     * @param checkOutDate Check-out date
     * @return List of room IDs that are available
     */
    public List<Integer> getAvailableRoomIds(Date checkInDate, Date checkOutDate) {
        List<Integer> availableRoomIds = new ArrayList<>();
        String sql = "SELECT r.room_id FROM rooms r " +
                     "WHERE r.is_available = TRUE " +
                     "AND r.room_id NOT IN (" +
                     "  SELECT b.room_id FROM bookings b " +
                     "  WHERE b.booking_status != 'CANCELLED' " +
                     "  AND ((b.check_in_date <= ? AND b.check_out_date > ?) " +
                     "  OR (b.check_in_date < ? AND b.check_out_date >= ?) " +
                     "  OR (b.check_in_date >= ? AND b.check_out_date <= ?))" +
                     ")";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setDate(1, checkOutDate);
            stmt.setDate(2, checkInDate);
            stmt.setDate(3, checkOutDate);
            stmt.setDate(4, checkInDate);
            stmt.setDate(5, checkInDate);
            stmt.setDate(6, checkOutDate);
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                availableRoomIds.add(rs.getInt("room_id"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting available room IDs: " + e.getMessage());
        }
        
        return availableRoomIds;
    }
    
    /**
     * Extract a Booking object from a ResultSet
     * @param rs ResultSet containing booking data
     * @return Booking object
     * @throws SQLException if a database access error occurs
     */
    private Booking extractBookingFromResultSet(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setBookingId(rs.getInt("booking_id"));
        booking.setUserId(rs.getInt("user_id"));
        booking.setRoomId(rs.getInt("room_id"));
        booking.setCheckInDate(rs.getDate("check_in_date"));
        booking.setCheckOutDate(rs.getDate("check_out_date"));
        booking.setTotalPrice(rs.getBigDecimal("total_price"));
        booking.setBookingStatus(rs.getString("booking_status"));
        booking.setCreatedAt(rs.getTimestamp("created_at"));
        booking.setUpdatedAt(rs.getTimestamp("updated_at"));
        return booking;
    }
}
