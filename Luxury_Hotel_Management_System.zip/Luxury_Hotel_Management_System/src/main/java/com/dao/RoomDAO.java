package com.dao;

import com.model.Room;
import com.util.DatabaseUtil;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Room entity
 */
public class RoomDAO {
    
    /**
     * Get all rooms from the database
     * @return List of all rooms
     */
    public List<Room> getAllRooms() {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM rooms";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                rooms.add(extractRoomFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all rooms: " + e.getMessage());
        }
        
        return rooms;
    }
    
    /**
     * Get a room by ID
     * @param roomId Room ID to search for
     * @return Room object if found, null otherwise
     */
    public Room getRoomById(int roomId) {
        String sql = "SELECT * FROM rooms WHERE room_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, roomId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return extractRoomFromResultSet(rs);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting room by ID: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Get rooms by type
     * @param roomType Type of room to search for
     * @return List of rooms of the specified type
     */
    public List<Room> getRoomsByType(String roomType) {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM rooms WHERE room_type = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, roomType);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                rooms.add(extractRoomFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting rooms by type: " + e.getMessage());
        }
        
        return rooms;
    }
    
    /**
     * Get rooms by price range
     * @param minPrice Minimum price
     * @param maxPrice Maximum price
     * @return List of rooms within the specified price range
     */
    public List<Room> getRoomsByPriceRange(BigDecimal minPrice, BigDecimal maxPrice) {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM rooms WHERE price_per_night BETWEEN ? AND ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBigDecimal(1, minPrice);
            stmt.setBigDecimal(2, maxPrice);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                rooms.add(extractRoomFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting rooms by price range: " + e.getMessage());
        }
        
        return rooms;
    }
    
    /**
     * Get available rooms
     * @return List of available rooms
     */
    public List<Room> getAvailableRooms() {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM rooms WHERE is_available = TRUE";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                rooms.add(extractRoomFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting available rooms: " + e.getMessage());
        }
        
        return rooms;
    }
    
    /**
     * Update room availability
     * @param roomId Room ID to update
     * @param isAvailable New availability status
     * @return true if successful, false otherwise
     */
    public boolean updateRoomAvailability(int roomId, boolean isAvailable) {
        String sql = "UPDATE rooms SET is_available = ? WHERE room_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setBoolean(1, isAvailable);
            stmt.setInt(2, roomId);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating room availability: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Extract a Room object from a ResultSet
     * @param rs ResultSet containing room data
     * @return Room object
     * @throws SQLException if a database access error occurs
     */
    private Room extractRoomFromResultSet(ResultSet rs) throws SQLException {
        Room room = new Room();
        room.setRoomId(rs.getInt("room_id"));
        room.setRoomNumber(rs.getString("room_number"));
        room.setRoomType(rs.getString("room_type"));
        room.setPricePerNight(rs.getBigDecimal("price_per_night"));
        room.setCapacity(rs.getInt("capacity"));
        room.setDescription(rs.getString("description"));
        room.setAvailable(rs.getBoolean("is_available"));
        room.setCreatedAt(rs.getTimestamp("created_at"));
        room.setUpdatedAt(rs.getTimestamp("updated_at"));
        return room;
    }
}
