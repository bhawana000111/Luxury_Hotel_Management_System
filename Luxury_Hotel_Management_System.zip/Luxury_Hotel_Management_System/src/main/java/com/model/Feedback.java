package com.model;

import java.sql.Timestamp;

/**
 * Feedback model class representing guest feedback for a stay
 */
public class Feedback {
    private int feedbackId;
    private int userId;
    private Integer bookingId; // Can be null
    private String comment;
    private int rating;
    private Timestamp dateSubmitted;
    private boolean isPublished;
    private String staffResponse;
    private Timestamp responseDate;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    
    // For displaying in views
    private String guestName;
    private String roomNumber;

    // Default constructor
    public Feedback() {
    }

    // Constructor with essential fields
    public Feedback(int userId, Integer bookingId, String comment, int rating) {
        this.userId = userId;
        this.bookingId = bookingId;
        this.comment = comment;
        this.rating = rating;
        this.isPublished = false;
    }

    // Full constructor
    public Feedback(int feedbackId, int userId, Integer bookingId, String comment, int rating,
                   Timestamp dateSubmitted, boolean isPublished, String staffResponse, 
                   Timestamp responseDate, Timestamp createdAt, Timestamp updatedAt) {
        this.feedbackId = feedbackId;
        this.userId = userId;
        this.bookingId = bookingId;
        this.comment = comment;
        this.rating = rating;
        this.dateSubmitted = dateSubmitted;
        this.isPublished = isPublished;
        this.staffResponse = staffResponse;
        this.responseDate = responseDate;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // Getters and Setters
    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Timestamp getDateSubmitted() {
        return dateSubmitted;
    }

    public void setDateSubmitted(Timestamp dateSubmitted) {
        this.dateSubmitted = dateSubmitted;
    }

    public boolean isPublished() {
        return isPublished;
    }

    public void setPublished(boolean published) {
        isPublished = published;
    }

    public String getStaffResponse() {
        return staffResponse;
    }

    public void setStaffResponse(String staffResponse) {
        this.staffResponse = staffResponse;
    }

    public Timestamp getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Timestamp responseDate) {
        this.responseDate = responseDate;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public Timestamp getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "feedbackId=" + feedbackId +
                ", userId=" + userId +
                ", bookingId=" + bookingId +
                ", rating=" + rating +
                ", dateSubmitted=" + dateSubmitted +
                ", isPublished=" + isPublished +
                '}';
    }
}
