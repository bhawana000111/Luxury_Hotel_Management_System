package com.util;

import com.model.User;
import java.lang.reflect.Method;

/**
 * Adapter for handling User class compatibility issues between different packages
 */
public class UserClassAdapter {
    
    /**
     * Get a property from any User-like object using reflection
     * @param userObject The user object (can be from any package)
     * @param propertyName The name of the property to get
     * @return The property value, or null if not found
     */
    public static Object getUserProperty(Object userObject, String propertyName) {
        if (userObject == null) {
            return null;
        }
        
        try {
            // Try to find a getter method for the property
            String getterName = "get" + propertyName.substring(0, 1).toUpperCase() + propertyName.substring(1);
            Method getter = userObject.getClass().getMethod(getterName);
            return getter.invoke(userObject);
        } catch (Exception e) {
            System.err.println("Error getting property " + propertyName + " from user object: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Create a User object from any User-like object using reflection
     * @param userObject The user object (can be from any package)
     * @return A new User object with the same data
     */
    public static User adaptUserObject(Object userObject) {
        if (userObject == null) {
            return null;
        }
        
        // If it's already a com.model.User, just return it
        if (userObject instanceof User) {
            return (User) userObject;
        }
        
        try {
            // Create a new User object
            User user = new User();
            
            // Try to copy properties using reflection
            try { user.setUserId(((Number) getUserProperty(userObject, "userId")).intValue()); } catch (Exception e) {}
            try { user.setUsername((String) getUserProperty(userObject, "username")); } catch (Exception e) {}
            try { user.setPassword((String) getUserProperty(userObject, "password")); } catch (Exception e) {}
            try { user.setEmail((String) getUserProperty(userObject, "email")); } catch (Exception e) {}
            try { user.setFirstName((String) getUserProperty(userObject, "firstName")); } catch (Exception e) {}
            try { user.setLastName((String) getUserProperty(userObject, "lastName")); } catch (Exception e) {}
            try { user.setPhone((String) getUserProperty(userObject, "phone")); } catch (Exception e) {}
            try { user.setAddress((String) getUserProperty(userObject, "address")); } catch (Exception e) {}
            try { user.setRole((String) getUserProperty(userObject, "role")); } catch (Exception e) {}
            
            return user;
        } catch (Exception e) {
            System.err.println("Error adapting user object: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Check if an object is a User-like object (has common User properties)
     * @param obj The object to check
     * @return true if the object is User-like, false otherwise
     */
    public static boolean isUserLikeObject(Object obj) {
        if (obj == null) {
            return false;
        }
        
        try {
            // Check for common User properties
            Method getUsernameMethod = obj.getClass().getMethod("getUsername");
            Method getRoleMethod = obj.getClass().getMethod("getRole");
            
            // If both methods exist, it's probably a User-like object
            return getUsernameMethod != null && getRoleMethod != null;
        } catch (Exception e) {
            return false;
        }
    }
}
