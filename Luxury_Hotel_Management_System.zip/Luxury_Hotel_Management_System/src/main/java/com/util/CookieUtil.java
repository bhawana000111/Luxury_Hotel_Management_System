package com.util;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Utility class for cookie management
 */
public class CookieUtil {
    
    // Default cookie max age (30 days in seconds)
    private static final int DEFAULT_MAX_AGE = 30 * 24 * 60 * 60;
    
    /**
     * Add a cookie to the response
     * @param response HttpServletResponse
     * @param name Cookie name
     * @param value Cookie value
     * @param maxAge Cookie max age in seconds
     */
    public static void addCookie(HttpServletResponse response, String name, String value, int maxAge) {
        Cookie cookie = new Cookie(name, value);
        cookie.setMaxAge(maxAge);
        cookie.setPath("/");
        cookie.setHttpOnly(true); // Prevent JavaScript access to the cookie
        response.addCookie(cookie);
    }
    
    /**
     * Add a cookie to the response with default max age
     * @param response HttpServletResponse
     * @param name Cookie name
     * @param value Cookie value
     */
    public static void addCookie(HttpServletResponse response, String name, String value) {
        addCookie(response, name, value, DEFAULT_MAX_AGE);
    }
    
    /**
     * Get a cookie value by name
     * @param request HttpServletRequest
     * @param name Cookie name
     * @return Cookie value if found, null otherwise
     */
    public static String getCookieValue(HttpServletRequest request, String name) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (name.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
    
    /**
     * Delete a cookie
     * @param response HttpServletResponse
     * @param name Cookie name
     */
    public static void deleteCookie(HttpServletResponse response, String name) {
        Cookie cookie = new Cookie(name, "");
        cookie.setMaxAge(0);
        cookie.setPath("/");
        response.addCookie(cookie);
    }
    
    /**
     * Set a remember me cookie
     * @param response HttpServletResponse
     * @param username Username to remember
     * @param token Token for authentication
     */
    public static void setRememberMeCookie(HttpServletResponse response, String username, String token) {
        addCookie(response, "remember_user", username);
        addCookie(response, "remember_token", token);
    }
    
    /**
     * Delete remember me cookies
     * @param response HttpServletResponse
     */
    public static void deleteRememberMeCookies(HttpServletResponse response) {
        deleteCookie(response, "remember_user");
        deleteCookie(response, "remember_token");
    }
}
