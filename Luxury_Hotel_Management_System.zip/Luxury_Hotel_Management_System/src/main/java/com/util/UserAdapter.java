package com.util;

import com.model.User;

/**
 * Adapter class to handle User class compatibility issues
 */
public class UserAdapter {
    
    /**
     * Convert a User object to a compatible format for session storage
     * This helps prevent class casting issues between different User class implementations
     * 
     * @param user The original User object
     * @return A new User object with the same data
     */
    public static User adaptUser(User user) {
        if (user == null) {
            return null;
        }
        
        // Create a new User object with the same data
        User adaptedUser = new User();
        adaptedUser.setUserId(user.getUserId());
        adaptedUser.setUsername(user.getUsername());
        adaptedUser.setPassword(user.getPassword());
        adaptedUser.setEmail(user.getEmail());
        adaptedUser.setFirstName(user.getFirstName());
        adaptedUser.setLastName(user.getLastName());
        adaptedUser.setPhone(user.getPhone());
        adaptedUser.setAddress(user.getAddress());
        adaptedUser.setRole(user.getRole());
        adaptedUser.setCreatedAt(user.getCreatedAt());
        adaptedUser.setUpdatedAt(user.getUpdatedAt());
        
        return adaptedUser;
    }
}
