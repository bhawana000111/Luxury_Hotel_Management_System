package com.util;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

/**
 * Utility class for file operations
 */
public class FileUtil {
    
    // Maximum file size (5MB)
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;
    
    // Allowed image file extensions
    private static final String[] ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif"};
    
    /**
     * Upload a file to the server
     * @param part The file part from multipart request
     * @param uploadDir The directory to upload to
     * @return The filename of the uploaded file
     * @throws IOException If an I/O error occurs
     */
    public static String uploadFile(Part part, String uploadDir) throws IOException {
        // Validate file size
        if (part.getSize() > MAX_FILE_SIZE) {
            throw new IOException("File size exceeds maximum limit");
        }
        
        // Get file name and extension
        String fileName = getSubmittedFileName(part);
        String fileExtension = getFileExtension(fileName);
        
        // Generate a unique file name
        String uniqueFileName = UUID.randomUUID().toString() + fileExtension;
        
        // Create upload directory if it doesn't exist
        Path uploadPath = Paths.get(uploadDir);
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }
        
        // Save the file
        try (InputStream input = part.getInputStream()) {
            Path filePath = uploadPath.resolve(uniqueFileName);
            Files.copy(input, filePath, StandardCopyOption.REPLACE_EXISTING);
            return uniqueFileName;
        }
    }
    
    /**
     * Upload an image file to the server
     * @param part The file part from multipart request
     * @param uploadDir The directory to upload to
     * @return The filename of the uploaded image
     * @throws IOException If an I/O error occurs
     */
    public static String uploadImage(Part part, String uploadDir) throws IOException {
        // Get file name and extension
        String fileName = getSubmittedFileName(part);
        String fileExtension = getFileExtension(fileName).toLowerCase();
        
        // Validate file extension
        boolean isValidExtension = false;
        for (String ext : ALLOWED_IMAGE_EXTENSIONS) {
            if (fileExtension.equals(ext)) {
                isValidExtension = true;
                break;
            }
        }
        
        if (!isValidExtension) {
            throw new IOException("Invalid image file extension");
        }
        
        return uploadFile(part, uploadDir);
    }
    
    /**
     * Delete a file from the server
     * @param filePath The path of the file to delete
     * @return true if the file was deleted, false otherwise
     */
    public static boolean deleteFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            return Files.deleteIfExists(path);
        } catch (IOException e) {
            return false;
        }
    }
    
    /**
     * Get the submitted file name from a Part
     * @param part The file part from multipart request
     * @return The submitted file name
     */
    private static String getSubmittedFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] items = contentDisposition.split(";");
        
        for (String item : items) {
            if (item.trim().startsWith("filename")) {
                return item.substring(item.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        
        return "";
    }
    
    /**
     * Get the file extension from a file name
     * @param fileName The file name
     * @return The file extension (including the dot)
     */
    private static String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < fileName.length() - 1) {
            return fileName.substring(dotIndex);
        }
        return "";
    }
    
    /**
     * Process file upload from a multipart request
     * @param request The HTTP request
     * @param fieldName The form field name
     * @param uploadDir The directory to upload to
     * @return The filename of the uploaded file
     * @throws IOException If an I/O error occurs
     * @throws ServletException If a servlet error occurs
     */
    public static String processFileUpload(HttpServletRequest request, String fieldName, String uploadDir) 
            throws IOException, ServletException {
        Part filePart = request.getPart(fieldName);
        if (filePart != null && filePart.getSize() > 0) {
            return uploadFile(filePart, uploadDir);
        }
        return null;
    }
}
