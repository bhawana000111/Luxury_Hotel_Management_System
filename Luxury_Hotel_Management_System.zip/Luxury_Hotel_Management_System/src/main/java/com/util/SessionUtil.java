package com.util;

import com.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.Date;

// Import the adapter for handling User class compatibility issues
import com.util.UserClassAdapter;

/**
 * Utility class for session management
 */
public class SessionUtil {
    private static final String USER_SESSION_KEY = "currentUser";
    private static final String LAST_ACTIVITY_KEY = "lastActivity";
    private static final int SESSION_TIMEOUT = 30 * 60; // 30 minutes in seconds

    /**
     * Set the current user in the session
     * @param request HttpServletRequest
     * @param user User to set in session
     */
    public static void setCurrentUser(HttpServletRequest request, User user) {
        HttpSession session = request.getSession(true);
        // Use the adapter to ensure class compatibility
        User adaptedUser = UserClassAdapter.adaptUserObject(user);
        session.setAttribute(USER_SESSION_KEY, adaptedUser);
        updateLastActivity(session);
    }

    /**
     * Get the current user from the session
     * @param request HttpServletRequest
     * @return User object if found in session, null otherwise
     */
    public static User getCurrentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            try {
                Object userObj = session.getAttribute(USER_SESSION_KEY);
                if (userObj == null) {
                    return null;
                }

                // Log the class type for debugging
                System.out.println("User object in session is of type: " + userObj.getClass().getName());

                // Use the adapter to handle different User class types
                return UserClassAdapter.adaptUserObject(userObj);
            } catch (Exception e) {
                // Log the error
                System.err.println("Error getting user from session: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return null;
    }

    /**
     * Check if a user is logged in
     * @param request HttpServletRequest
     * @return true if user is logged in, false otherwise
     */
    public static boolean isLoggedIn(HttpServletRequest request) {
        return getCurrentUser(request) != null;
    }

    /**
     * Check if the current user is an admin
     * @param request HttpServletRequest
     * @return true if user is an admin, false otherwise
     */
    public static boolean isAdmin(HttpServletRequest request) {
        User user = getCurrentUser(request);
        return user != null && "ADMIN".equals(user.getRole());
    }

    /**
     * Invalidate the current session
     * @param request HttpServletRequest
     */
    public static void invalidateSession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }

    /**
     * Update the last activity timestamp in the session
     * @param session HttpSession
     */
    private static void updateLastActivity(HttpSession session) {
        session.setAttribute(LAST_ACTIVITY_KEY, System.currentTimeMillis());
    }

    /**
     * Check if the session has timed out
     * @param request HttpServletRequest
     * @return true if the session has timed out, false otherwise
     */
    public static boolean isSessionTimedOut(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return true;
        }

        Long lastActivity = (Long) session.getAttribute(LAST_ACTIVITY_KEY);
        if (lastActivity == null) {
            return true;
        }

        long currentTime = System.currentTimeMillis();
        long elapsedTime = (currentTime - lastActivity) / 1000; // Convert to seconds

        return elapsedTime > SESSION_TIMEOUT;
    }

    /**
     * Refresh the session by updating the last activity timestamp
     * @param request HttpServletRequest
     */
    public static void refreshSession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            updateLastActivity(session);
        }
    }

    /**
     * Get the session creation time
     * @param request HttpServletRequest
     * @return Date object representing the session creation time, or null if no session exists
     */
    public static Date getSessionCreationTime(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return new Date(session.getCreationTime());
        }
        return null;
    }

    /**
     * Get the session last accessed time
     * @param request HttpServletRequest
     * @return Date object representing the session last accessed time, or null if no session exists
     */
    public static Date getSessionLastAccessedTime(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            return new Date(session.getLastAccessedTime());
        }
        return null;
    }
}
