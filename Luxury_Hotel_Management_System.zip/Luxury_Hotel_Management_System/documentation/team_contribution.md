6.1. Team Contribution

Member Name: Bhawana Ghimire
- Database and Authentication System
  · Design and implement MySQL database schema
  · Create SQL scripts for tables and relationships
  · Implement database connection utilities (using HikariCP)
  · Implement login/logout functionality
  · Session management
  · Password encryption
  · Role-based access control
  .Documentation
  Files: 
  - src/main/resources/database/*.sql
  - src/main/java/com/example/luxury_hotel_management_system/dao/*
  - src/main/java/com/example/luxury_hotel_management_system/filter/AuthenticationFilter.java
  - */LoginServlet.java

Member Name: Sudip Mani Gautam
- Booking and Room Management System
  · Room booking functionality
  · Booking status management
  · Payment processing
  · Booking confirmation emails
  · Room availability checking
  · Room type management
  · Room pricing system
  Files:
  - src/main/java/com/example/luxury_hotel_management_system/controller/BookingController.java
  - */service/BookingService.java
  - src/main/java/com/example/luxury_hotel_management_system/model/Room.java
  - */RoomController.java

Member Name: Sakila Shrestha
- Frontend Development and UI/UX
  · Frontend development using JSP
  · Responsive design implementation
  · CSS styling and layout
  · JavaScript interactions
  · Client-side form validation
  · Error handling and display
  · UI/UX design for all pages
  Files:
  - src/main/webapp/WEB-INF/views/*
  - src/main/webapp/resources/css/*
  - src/main/webapp/resources/js/*
  - src/main/webapp/resources/js/validation.js

Member Name: Roshni Tamang
- User Management and Admin System
  · User registration system
  · Profile management
  · Password reset functionality
  · User roles and permissions
  · Admin interface development
  · System statistics and reports
  · User management interface
  Files:
  - src/main/java/com/example/luxury_hotel_management_system/controller/RegisterServlet.java
  - */UserService.java
  - src/main/webapp/WEB-INF/views/admin/*

Member Name: Saurav Basnet
- Security, Testing and Integration
  · Security configurations
  · Input validation
  · XSS prevention
  · CSRF protection
  · Unit testing
  · Integration testing
  · System testing
  Files:
  - src/main/java/com/example/luxury_hotel_management_system/security/*
  - src/test/java/*
  - pom.xml
  - README.md

For each team member's documentation:

6.1.1. Individual Contribution Format

a. Feature Implementation
- Description of the feature
- Technical approach
- Code snippets and explanations
- Screenshots of implementation
- Citations for any external resources used

b. UI/UX Design (if applicable)
- Design decisions
- Wireframes/mockups
- Implementation screenshots
- User feedback and iterations
- Citations for design inspiration

c. Critical Analysis

Challenges:
1. Challenge: [Name]
   - Issue: [Describe the technical challenge]
   - Solution: [How you solved it]
   - Evidence: [Screenshots, code snippets, or metrics]
   - Citation: [If external resources were used]

Problems Faced:
1. Problem: [Name]
   - Issue: [Describe the problem]
   - Solution: [How you overcame it]
   - Evidence: [Screenshots, code snippets, or metrics]
   - Citation: [If external resources were used]

Example Documentation (for Database Implementation):

a. Feature Implementation: Database Connection Pool
- Description: Implemented connection pooling to improve database performance
- Technical Approach: Used HikariCP for connection pooling
- Code Implementation:
  ```java
  public class DatabaseUtil {
      private static HikariDataSource dataSource;
      
      static {
          HikariConfig config = new HikariConfig();
          config.setJdbcUrl("jdbc:mysql://localhost:3306/luxury_hotel_db");
          config.setUsername("root");
          config.setPassword("password");
          config.setMaximumPoolSize(10);
          dataSource = new HikariDataSource(config);
      }
  }
  ```
- Screenshot: [Add screenshot of performance metrics]
- Citation: HikariCP Documentation (https://github.com/brettwooldridge/HikariCP)

b. Critical Analysis:
Challenge: Database Connection Management
- Issue: Initial implementation had connection leaks
- Solution: Implemented proper connection closing in finally blocks
- Evidence: Connection pool metrics showing no leaks
- Citation: JDBC Best Practices (java.sun.com)